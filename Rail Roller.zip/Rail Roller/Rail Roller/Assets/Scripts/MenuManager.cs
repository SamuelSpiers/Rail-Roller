﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour {

    public AudioSource Music;
    public AudioClip MenuMusic;
    private Scene currentScene;
    private string sceneName;

    void Start ()
    {
        Cursor.visible = true;
        currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;
        if (sceneName == "MainMenu")
        {
            Music.clip = MenuMusic;
            Music.Play();
        }
    }
}
