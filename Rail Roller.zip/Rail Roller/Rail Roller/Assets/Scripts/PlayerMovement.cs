﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour {

    public float speed;
    public static bool canJump;
    public float durationMaster;
    public float NormalJumpforce;
    public float InvertedJumpforce;

    public static Rigidbody Playerbody;
    public Text durationDisplay;
    public Text TutorialDisplay;
    public Text victoryDisplay;
    public GameObject PauseMenu;
    public Camera mainCamera;

    public Color PlayerColor;
    public Color PlayerColor2;
    public static string Colorstate;

    private Renderer PlayerRenderer;
    private float jumpforce;
    private bool ZeroGrav;
    private Scene currentScene;
    private string sceneName;

    //PowerUp variables
    private float duration;
    private bool poweredUp;
    private bool PU_Speed;
    private bool PU_Jump;
    [HideInInspector]public static bool PU_Destroy;
    private string currentPU;

    //Audio variables
    [HideInInspector]public static AudioSource sfx_Player;
    public AudioClip Jump;
    public AudioClip PowerUp;
    public AudioClip TextPopup;
    public AudioClip Victory;

    void Start()
    {
        //Get component references/set starting values
        Playerbody = GetComponent<Rigidbody>();
        PlayerRenderer = GetComponent<Renderer>();
        sfx_Player = GetComponent<AudioSource>();
        PlayerRenderer.material.color = PlayerColor;
        jumpforce = NormalJumpforce;
        Colorstate = "Yellow";
        ZeroGrav = false;
        poweredUp = false;
        duration = durationMaster;
        currentPU = "none";
        currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;
    }

    void Update()
    {
        //Controlling PowerUp duration timer
        if (poweredUp)
        {
            PowerupTimer();
            if(PU_Speed)
            {
                currentPU = "Speed Boost";
            }
            else if(PU_Jump)
            {
                currentPU = "Jump Boost";
            }
            else if(PU_Destroy)
            {
                currentPU = "Destroyer";
            }
        }
        if(sceneName == "Tutorial Level")
        {
            if (Time.time >= 1 && Time.time <= 1.1)
            {
                TutorialDisplay.text = "Use WASD or the arrow keys to move";
                PlayNotificationSound();
            }
        }
    }
	
	void FixedUpdate()
    {
        //Player Movement Controls
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
        float moveVertical = Input.GetAxisRaw("Vertical");
        Vector3 horizontalmovement = mainCamera.transform.right * moveHorizontal * speed;
        Playerbody.AddForce(horizontalmovement);
        Vector3 dir = Camera.main.transform.forward;
        dir.y = 0;
        Playerbody.AddForce(dir.normalized * speed * moveVertical);
        //Player Colour Controls
        if (Colorstate == "Yellow" && Input.GetKeyDown(KeyCode.Mouse0))
        {
            Colorstate = "Blue";
            PlayerRenderer.material.color = PlayerColor2;
        }
        else if (Colorstate == "Blue" && Input.GetKeyDown(KeyCode.Mouse0))
        {
            Colorstate = "Yellow";
            PlayerRenderer.material.color = PlayerColor;
        }
        //Player Jumping Controls (Gravity)
        if (ZeroGrav == false)
        {
            if (canJump)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    canJump = false;
                    Playerbody.velocity += jumpforce * Vector3.up;
                    sfx_Player.clip = Jump;
                    sfx_Player.Play();
                }
            }
        }
        //Player Jumping Controls (Zero Gravity)
        else if (ZeroGrav == true)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                Playerbody.AddForce(-Physics.gravity, ForceMode.Acceleration);
            }
            else if (Input.GetKey(KeyCode.LeftShift))
            {
                Playerbody.AddForce(Physics.gravity, ForceMode.Acceleration);
            }
        }
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(PauseMenu.activeSelf == false)
            {
                PauseMenu.SetActive(true);
                Cursor.visible = true;
            }
            else if (PauseMenu.activeSelf == true)
            {
                PauseMenu.SetActive(false);
                Cursor.visible = false;
            }
        }
    }
    //Below is all trigger control
    void OnTriggerEnter(Collider other)
    {
        PlayerController.Respawned = false;
        if (other.transform.tag == "GravInvert")
        {
            Playerbody.useGravity = false;
            jumpforce = InvertedJumpforce;
        }
        else if (other.transform.tag == "ZeroGrav")
        {
            Playerbody.useGravity = false;
            ZeroGrav = true;
        }
        else if (other.transform.tag == "PU_Speed")
        {
            other.gameObject.SetActive(false);
            poweredUp = true;
            PU_Speed = true;
            speed = speed * 2;
            PlayPowerUpSound();
        }
        else if (other.transform.tag == "PU_Jump")
        {
            other.gameObject.SetActive(false);
            poweredUp = true;
            PU_Jump = true;
            jumpforce = jumpforce * 3;
            PlayPowerUpSound();
        }
        else if (other.transform.tag == "PU_Destroy")
        {
            other.gameObject.SetActive(false);
            poweredUp = true;
            PU_Destroy = true;
            PlayPowerUpSound();
        }
        else if (other.transform.tag == "Finish")
        {
            victoryDisplay.text = "Victory!";
            PlayVictorySound();
        }
        else if (other.transform.tag == "Tutorial 1")
        {
            TutorialDisplay.text = "Use the mouse and scroll wheel to control the camera";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 2")
        {
            TutorialDisplay.text = "Press the left mouse button to change your colour";
            PlayNotificationSound();

        }
        else if (other.transform.tag == "Tutorial 3")
        {
            TutorialDisplay.text = "If a platform is yellow or blue, you must be its colour";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 4")
        {
            TutorialDisplay.text = "Press SPACE to jump";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 5")
        {
            TutorialDisplay.text = "Don't worry, inverted gravity!";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 6")
        {
            TutorialDisplay.text = "Get ready for some zero gravity!";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 7")
        {
            TutorialDisplay.text = "This is the Speed Boost power up. Jump the gap";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 8")
        {
            TutorialDisplay.text = "This is the Jump Boost power up. Jump up the wall";
            PlayNotificationSound();
        }
        else if (other.transform.tag == "Tutorial 9")
        {
            TutorialDisplay.text = "This is the Destroyer power up. While this is active you can destroy dangers";
            PlayNotificationSound();
        }
    }

    void OnTriggerStay(Collider other)
    {
        if(other.transform.tag == "GravInvert")
        {
            Playerbody.AddForce(-Physics.gravity, ForceMode.Acceleration);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if(other.transform.tag == "GravInvert")
        {
            Playerbody.useGravity = true;
            jumpforce = NormalJumpforce;
        }
        else if(other.transform.tag == "ZeroGrav")
        {
            Playerbody.useGravity = true;
            ZeroGrav = false;
        }
    }

    void PowerupTimer()
    {
        duration -= Time.deltaTime;
        durationDisplay.text = currentPU + ": " + Mathf.Round(duration);
        if(duration <= 0 || PlayerController.Respawned)
        {
            duration = durationMaster;
            durationDisplay.text = "";
            PowerupShutdown();
            PlayerController.Respawned = false;
        }
    }

    void PowerupShutdown()
    {
        if (PU_Speed)
        {
            PU_Speed = false;
            poweredUp = false;
            speed = speed / 2;
        }
        else if (PU_Jump)
        {
            PU_Jump = false;
            poweredUp = false;
            jumpforce = jumpforce / 3;
        }
        else if (PU_Destroy)
        {
            PU_Destroy = false;
            poweredUp = false;
        }
    }

    public void PlayNotificationSound()
    {
        sfx_Player.clip = TextPopup;
        sfx_Player.Play();
    }

    void PlayPowerUpSound()
    {
        sfx_Player.clip = PowerUp;
        sfx_Player.Play();
    }

    void PlayVictorySound()
    {
        sfx_Player.clip = Victory;
        sfx_Player.Play();
    }
}