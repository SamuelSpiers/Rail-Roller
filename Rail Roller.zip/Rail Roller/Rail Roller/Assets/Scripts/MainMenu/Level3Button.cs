﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Level3Button : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;
	
	public void LoadLvl3()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        SceneManager.LoadScene("Level 3");
	}
}
