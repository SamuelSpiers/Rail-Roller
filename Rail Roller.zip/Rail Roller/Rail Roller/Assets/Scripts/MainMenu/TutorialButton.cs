﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class TutorialButton : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;
	
	public void LoadTutorial()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        SceneManager.LoadScene("Tutorial Level");
	}
}
