﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Level1Button : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;
	
	public void LoadLvl1()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        SceneManager.LoadScene("Level 1");
	}
}
