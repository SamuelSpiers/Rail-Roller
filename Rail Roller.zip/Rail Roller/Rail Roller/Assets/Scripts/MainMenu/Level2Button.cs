﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Level2Button : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;
	
	public void LoadLvl2()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        SceneManager.LoadScene("Level 2");
	}
}
