﻿using UnityEngine;

public class CloseButton : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;

    public void Close()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        Application.Quit();
    }
}
