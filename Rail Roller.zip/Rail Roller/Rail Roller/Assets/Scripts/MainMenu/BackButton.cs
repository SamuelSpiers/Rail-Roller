﻿using UnityEngine;

public class BackButton : MonoBehaviour {

    private Animation ani;
    public AudioSource menuSFX;
    public AudioClip buttonPress;

    void Start()
    {
        ani = GetComponent<Animation>();
        ani.Stop();
    }

    public void PlayAnimation()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        ani.Play("ToMainPage");
    }
}
