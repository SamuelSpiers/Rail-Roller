﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public AudioSource Music;
    public AudioClip MenuMusic;
    public AudioClip GameMusic;
    public GameObject PauseMenu;
    private Scene currentScene;
    private string sceneName;

    void Start ()
    {
        //Remove the cursor
        Cursor.visible = false;
        PauseMenu.SetActive(false);
        currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;
        if (sceneName == "MainMenu")
        {
            Music.clip = MenuMusic;
            Music.Play();
        }
        if(sceneName != "MainMenu")
        {
            Music.clip = GameMusic;
            Music.Play();
        }
    }
}
