﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {

    public Transform CurrentCheckpoint;
    public GameObject PauseMenu;
    public AudioClip Death;

    private Vector3 checkpoint;
    private Quaternion spawnRotation;
    private Object[] Resettables;
    private bool Finished;
    private float duration;
    private float durationMaster;
    [HideInInspector]public static bool Respawned;

    void Start ()
    {
        //Setting level start checkpoint position and rotation
        checkpoint = new Vector3(0, 1, -3);
        spawnRotation.Set(0, 0, 0, 0);
        Resettables = Resources.FindObjectsOfTypeAll<GameObject>();
        Respawned = false;
        Finished = false;
        durationMaster = 8;
        duration = durationMaster;
    }

    void Update()
    {
        if(Finished)
        {
            duration -= Time.deltaTime;
            if (duration <= 0)
            {
                duration = durationMaster;
                SceneManager.LoadScene("MainMenu");
            }
        }
    }
	
	void FixedUpdate ()
    {
        //Have we fallen off the map? If so, respawn
        if (transform.position.y <= -10)
        {
            Respawn();
        }
    }
    void OnCollisionEnter(Collision col)
    {
        //Are we touching the ground? If so, allow jumping
        if (col.transform.tag == "Ground" || col.transform.tag == "GroundBlue" || col.transform.tag == "GroundYellow") PlayerMovement.canJump = true;
    }

    void OnCollisionStay(Collision col)
    {
        //Are we touching the wrong colour? If so, respawn
        if (col.transform.tag == "GroundBlue" && PlayerMovement.Colorstate != "Blue")
        {
            Respawn();
        }
        else if (col.transform.tag == "GroundYellow" && PlayerMovement.Colorstate != "Yellow")
        {
            Respawn();
        }

    }

    void OnTriggerEnter(Collider other)
    {
        //Setting a new checkpoint
        if (other.transform.tag == "CheckPoint")
        {
            CurrentCheckpoint.position = transform.position;
            checkpoint = (CurrentCheckpoint.position);

        }
        //Colliding with a Danger
        else if (other.transform.tag == "Danger")
        {
            if(PlayerMovement.PU_Destroy)
            {
                other.gameObject.SetActive(false);
            }
            else
            {
                Respawn();
            }
        }
        else if (other.transform.tag == "Finish")
        {
            Finished = true;
        }
    }
    void Respawn()
    {
        //Reset position and velocity
        transform.position = checkpoint;
        PlayerMovement.Playerbody.velocity = Vector3.zero;
        //Play death sound
        PlayerMovement.sfx_Player.clip = Death;
        PlayerMovement.sfx_Player.Play();
        //Reset world objects
        foreach (GameObject item in Resettables)
        {
            item.SetActive(true);
        }
        Respawned = true;
        PauseMenu.SetActive(false);
    }
}
