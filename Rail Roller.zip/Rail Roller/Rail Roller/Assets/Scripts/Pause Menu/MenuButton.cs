﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuButton : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;

    public void LoadMenu()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        SceneManager.LoadScene("MainMenu");
	}
}
