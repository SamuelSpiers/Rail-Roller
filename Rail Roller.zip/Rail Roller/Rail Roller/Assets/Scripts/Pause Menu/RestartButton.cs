﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartButton : MonoBehaviour {

    public AudioSource menuSFX;
    public AudioClip buttonPress;
    private Scene currentScene;
    private string sceneName;

    public void ReloadLevel()
    {
        menuSFX.clip = buttonPress;
        menuSFX.Play();
        currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;
        SceneManager.LoadScene(sceneName);
	}
}
